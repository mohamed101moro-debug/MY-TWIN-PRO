module.exports = 'mocked-file';
