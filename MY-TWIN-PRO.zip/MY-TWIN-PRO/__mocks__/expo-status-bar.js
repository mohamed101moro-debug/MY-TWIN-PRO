module.exports = { StatusBar: 'StatusBar' };
