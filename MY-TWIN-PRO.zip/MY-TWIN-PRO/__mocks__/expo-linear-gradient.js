module.exports = { LinearGradient: 'LinearGradient' };
